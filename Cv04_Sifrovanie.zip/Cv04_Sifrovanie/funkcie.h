#pragma once
char *kopirujRetazec(const char *zdrojRetazec);